package domain

data class Stock(

    val name: String,
    val initialPrice: Long

)

