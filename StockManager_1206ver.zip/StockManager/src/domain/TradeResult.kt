package domain

data class TradeResult(
    val success: Boolean,
    val message: String,
)