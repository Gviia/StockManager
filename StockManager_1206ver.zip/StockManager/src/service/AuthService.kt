package service



import domain.User
import repository.UserRepository

class AuthService(
    private val userRepository: UserRepository
) {

    // 회원가입
    fun register(userId: String, name: String, initialCash: Long = 500000): Boolean {
        // 이미 존재하는지 확인
        if (userRepository.findById(userId) != null) {
            return false // 중복 회원
        }

        val newUser = User(
            userId = userId,
            name = name,
            cash = initialCash
        )

        userRepository.save(newUser)
        return true
    }

    // 로그인
    fun login(userId: String): User? {
        return userRepository.findById(userId)
    }
}
